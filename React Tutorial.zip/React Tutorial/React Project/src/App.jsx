
import About from './About'
import { BrowserRouter as Router, Routes, Route } from "react-router-dom"
import Home from './Home'
import PNF from './PNF'

function App() {
  return (
    <>
      {/* {console.log(add(1, 2))} */}
      <Router>
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/about' element={<About />} />
          <Route path='*' element={<PNF />} />
        </Routes>
      </Router>
    </>
  )
}

export default App
