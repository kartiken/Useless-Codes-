
function About() {
    return (
        <>
            {/* {console.log(add(1, 2))} */}
            <div>
                <h1>klashdhadiu</h1>
            </div>
        </>
    )
}

export default About
