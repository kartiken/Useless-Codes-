
const a = 6;
const b = 10;
export const c = a + b;


// const add = (a, b) => {
//     return a + b;
// }
// export default add